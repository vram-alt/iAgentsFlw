import type { Metadata } from 'next'
import { getSiteUrl } from '@/lib/site-url'
import AuditReadinessClient from '@/components/AuditReadinessClient'

const siteUrl = getSiteUrl()

export const metadata: Metadata = {
  title: 'Audit Readiness - Managed Services | AgentsFlow AI',
  description: 'Managed audit readiness and evidence collection for AI compliance audits.',
  alternates: {
    canonical: `${siteUrl}/managed-services/audit-readiness`,
  },
}

export default function ManagedAuditReadinessPage() {
  return <AuditReadinessClient />
}

