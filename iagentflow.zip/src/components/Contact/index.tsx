import HeroSection from "./HeroSection";
import MapSection from "./MapSection";

export default function Contact() {
    return (
        <>
            <HeroSection />
            <MapSection />
        </>
    )
}